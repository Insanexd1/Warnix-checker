<!DOCTYPE html>
<?php
if (isset($_GET["submit"]) {
  // code...
  if ($_GET["password"] == "lord") {
    // code...
    yellow()
    return;
  }
  function yellow() {
    $_SESSION["login"] = true;
    header("location:login.php");
  }
}
?>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>⏤͟͟͞͞ 𝐋𝐎𝐑𝐃 𝐂𝐎𝐌𝐌𝐔𝐍𝐈𝐓𝐘</title>
  </head>
  <style type="text/css" media="all">
  *{
    color: white;
    padding: 0;
    margin: 0;
  }
    body {
      padding: 20px;
      background: black;
      text-align: center;
    }
    body * {
      margin-top: 20px ;
    }
    input[type=submit]{
      background: purple;
      border: none;
      border-radius: 0;
      height: 40px;
      width: auto;
      font-family: MONOSPACE;
      font-weight: 700;
      padding: 10px;
    }
    input[type=password] {
      background: black;
      padding: 10px;
      padding-left: 15px;
      border: 1px solid white;
    }
  </style>
  <body>
    <form action="" method="get" accept-charset="utf-8">
      
    
    <h1>⏤͟͟͞͞ 𝐋𝐎𝐑𝐃 𝐂𝐎𝐌𝐌𝐔𝐍𝐈𝐓𝐘</h1>
    <h2>Login To Continue</h2>
    <input type="password" name="password" id="password" value="" required/>
    <input type="submit" name="submit" id="submit" value="LOGIN" />
  
  </form>
  </body>
</html>